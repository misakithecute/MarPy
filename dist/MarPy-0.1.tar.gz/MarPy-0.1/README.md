# MarPy
A test package that I built for the Analyse Sprint at EDSA.
Mar for Marissa and Py for Python.
I'm good at naming things.


## Pronunciation
Mar - Pie
